TestPattern = [7 1 1 1 2
               7 1 2 2 1
               7 3 1 2 2];
         
save test_data TestPattern;